package com.hexaware.entity;

public enum LoanStatus {
    Pending,
    Approved
}
