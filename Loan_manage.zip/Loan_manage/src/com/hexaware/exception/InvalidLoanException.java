package com.hexaware.exception;

public class InvalidLoanException extends Exception{
	
	public InvalidLoanException(String res)
	{
		super(res);
	}

}
