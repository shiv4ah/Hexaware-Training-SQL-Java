package com.hexaware.controller;

public interface CustomerControllerInterface {
	
	void addCustomer();
	void updateCustomer();

}
